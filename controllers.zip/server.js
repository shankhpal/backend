const express = require('express');
const  connectDB = require("./config/db.js");
const path = require("path");
const dotenv= require("dotenv");
const bodyParser =require('body-parser');
const cors = require('cors');
const  config = require("./config/default.json");
const userRoutes = require("./routes/userRoutes.js");
const tweetRoutes=  require("./routes/tweetRoutes.js");
const commentRoutes = require("./routes/commentRoutes.js");
const elasticClient = require('./config/elasticSearch')
const { errorHandler, notFound }= require("./middleware/errorMiddleware.js");


dotenv.config();
connectDB();
const app = express();
app.use(cors()); 
app.options('*',cors())
app.use(bodyParser.urlencoded({
  extended:true
}))
app.use(express.json()); 
app.use("/api/v1.0/tweets", tweetRoutes);
app.use("/api/v1.0/tweets", userRoutes);
app.use("/api/v1.0/tweets",commentRoutes);

app.use(notFound);
app.use(errorHandler);

// const userIndexName = config.elasticsearch.elasticsearchIndices.USER.index;
// const userIndexType = config.elasticsearch.elasticsearchIndices.USER.type;
// const userTableName = config.elasticsearch.elasticsearchIndices.USER.collectionName;

// const tweetIndexName = config.elasticsearch.elasticsearchIndices.TWEET.index;
// const tweetIndexType = config.elasticsearch.elasticsearchIndices.TWEET.type;
// const tweetTableName = config.elasticsearch.elasticsearchIndices.TWEET.collectionName;

// const commentsIndexName = config.elasticsearch.elasticsearchIndices.COMMENTS.index;
// const commentsIndexType = config.elasticsearch.elasticsearchIndices.COMMENTS.type;
// const commentsTableName = config.elasticsearch.elasticsearchIndices.COMMENTS.collectionName;
 const server = require('http').createServer(app)
app.use((req, res, next)=>{
req.socket.on('error', () => {});
next()
});

server.on('listening', ()=>{
  console.log('server is runnig')
})

const PORT = process.env.PORT || config.application_serverport;

server.listen(
  PORT,
  console.log(
    `Server running in ${process.env.NODE_ENV} mode on port ${PORT}..`
  )
);