 const elasticsearch = require('elasticsearch');
const  config = require("../config/default.json");

var client = new elasticsearch.Client({
    hosts: config.elasticsearch.url + "" + config.elasticsearch.port,
    requestTimeout: 6 * 350 * 2500,
    requestTimeout:Infinity,
    keepAlive:false
    });

let itemQue = [];
let limitData =1000;
let offSet = 0;
let prev = 0;
let iIndex = 1;

function bulkop(data, callback){
    client.bulk({
        body: data
    }, function(error, res){
        if(callback){
            callback(error, res)
        }
    });
    data = [];
};

