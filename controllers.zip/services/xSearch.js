const elasticClient = require("../config/elasticSearch");

class XFactorSearch {
    constructor(meta){
        this.meta =meta;
        this.properties={};
        this.pf = new postFilter();
        this.query ={
            index: this.meta.index,
            type : this.meta.type,
            body :{
                "from": 0,
                "query":{
                    "bool":{
                        "must":[{
                            "match_all":{}
                        }]
                    }
                },
                "aggregation":{}
            }
        }
        this.print();
    }
  


    search(cb){
        let _this =this;
        if(this.pf.isEmpty()){
         this.query.body['post_filter']= this.pf.asJson();
         console.log(JSON.stringify(this.query));
        elasticClient.search(this.query).then((res)=>{
            let hits = res.hits.hits;
            let result = {
                "meta": _this.meta,
                "hits": hits,
                "agg": res.aggregations
            }
            res.status(200).json(result)
        }, error =>{
            console.trace(error.message)
            res.status(500).json({message:"something went wrong"});
          }).catch(err=>{
              res.status(500).json({message:"something went wrong"});
          })
        }
    }
}
